# React.js Tic Tac Toe Game in 30 Minutes
## Watch Video
[https://youtu.be/it54tShOsuI](https://youtu.be/it54tShOsuI)

 00:00:04 Introduction

 00:03:01 Square Component

 00:06:50 Board Component

 00:10:19 Game Component

 00:12:36 Render Method

 00:15:34 Handle Click

 00:19:38 Calculate Winner

 00:24:59 Game Info

 00:32:27 Make Beautiful

 00:33:01 Conclusion


## Learn React by Building a fun game in 30 minutes,
* Live Demo: https://basir.github.io/tic-tac-toe/
* Source Code: https://github.com/basir/tic-tac-toe
* Website: https://codingwithbasir.com

#reactjs #react #tutorial #tictactoe #videotutorial #javascript #junior #stepbystep #howtocode #reacttutorial #game #fun #learn #coding #programming